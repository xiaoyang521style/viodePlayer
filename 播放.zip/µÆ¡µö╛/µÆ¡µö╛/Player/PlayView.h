//
//  PlayView.h
//  播放
//
//  Created by Apple on 2017/6/27.
//  Copyright © 2017年 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
@interface PlayView : UIView

+(id)playViewWithFrame:(CGRect)frame playWithUrl:(NSString *)url;

@property (nonatomic, copy) void (^toFullScreenAction)(UIButton *fullScreenBtn);

@property (nonatomic, copy) void (^playEndBlock) ();

@property (nonatomic, copy) void (^joinTheStudyPlan)();
@property (strong, nonatomic) MPVolumeView *volumeView;//控制音量的view
@property(nonatomic,strong)NSString *url;
-(void)play;

-(void)pause;
@end
