//
//  PlayView.m
//  播放
//
//  Created by Apple on 2017/6/27.
//  Copyright © 2017年 Apple. All rights reserved.
//

#import "PlayView.h"
#import <AVFoundation/AVFoundation.h>
#import "VideoMaskView.h"
#import <AVKit/AVKit.h>
#import <MediaPlayer/MediaPlayer.h>
/**记录当前屏幕的方向
 并没有真正的改变设备的旋转方向，项目中所有的界面都是竖屏，这里只是记录下当前的视频播放是否是全屏
 **/
typedef NS_ENUM(NSInteger, CurrentDeviceDirection)  {
    
    Portrait, // 竖屏
    Right // 向右
    
};
typedef NS_ENUM(NSUInteger, Direction) {
    DirectionLeftOrRight,
    DirectionUpOrDown,
    DirectionNone
};

/**视频播放的状态**/
typedef NS_ENUM(NSInteger, PlayerState) {
    
    Playing, // 播放中
    Stoped, // 停止播放
    Pause, // 暂停播放
    ReadyToPlay //准备好播放了
    
} ;

@interface  PlayView ()<VideoMaskViewDelegate>


@property (nonatomic, strong) AVPlayer *player;

@property (nonatomic, strong) AVPlayerItem *playerItem;

@property (nonatomic, strong) AVPlayerLayer *playerLayer;

@property (nonatomic, assign) PlayerState playerState;

@property (nonatomic, strong) VideoMaskView *videoMaskView;

@property (nonatomic, assign) BOOL isUserPause;//标记是否是用户暂停播放

@property (nonatomic, assign) BOOL isDragSlider;

@property (nonatomic, assign) CurrentDeviceDirection currentDevDir;


@property (nonatomic, assign) CGRect smallFrame;

@property (nonatomic, assign) CGRect bigFrame;

@property (nonatomic, assign) NSInteger currentPlayTime;//当前播放时间（单位: S）

@property (nonatomic, assign) NSInteger totalTime; // 视频总时长（单位： S）



@property (strong, nonatomic) UISlider* volumeViewSlider;//控制音量

@property (assign, nonatomic) CGFloat currentRate;//当期视频播放的进度

@property (assign, nonatomic) Direction direction;

@property (assign, nonatomic) CGPoint startPoint;

@property (assign, nonatomic) CGFloat startVB;

@property (assign, nonatomic) CGFloat startVideoRate;

@property (assign, nonatomic) NSTimeInterval total;

@end

@implementation PlayView

- (void)toPortrait {
    
    if ([self isPortrait] == NO) {
        [self fullScreenClick:self.videoMaskView.fullScreenBtn];
    }
}

- (BOOL)isPortrait {
    
    return self.currentDevDir == Portrait;
}
+(id)playViewWithFrame:(CGRect)frame playWithUrl:(NSString *)url{

    PlayView *playView = [[PlayView alloc]initWithFrame:frame];
    
    playView.url = url;
    return playView;

}

-(void)setUrl:(NSString *)url{

    _url = url;
    self.isUserPause = NO;
    //将之前的监听时间移除掉。
    [self.playerItem removeObserver:self forKeyPath:@"status"];
    [self.playerItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
    [self.playerItem removeObserver:self forKeyPath:@"playbackBufferEmpty"];
    [self.playerItem removeObserver:self forKeyPath:@"playbackLikelyToKeepUp"];
    self.playerItem = nil;

    if ([NSURL URLWithString:self.url]) {
        self.playerItem = [AVPlayerItem playerItemWithURL:[NSURL URLWithString:_url]];
        [self.player replaceCurrentItemWithPlayerItem:self.playerItem];
       
        
        if([[UIDevice currentDevice] systemVersion].floatValue >= 10.0){
            //      增加下面这行可以解决iOS10兼容性问题了
            self.player.automaticallyWaitsToMinimizeStalling = NO;
        }
        
        // AVPlayer播放完成通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playDidEnd:) name:AVPlayerItemDidPlayToEndTimeNotification object:self.player.currentItem];
        [[NSNotificationCenter defaultCenter]addObserver:self
         
                                                selector:@selector(playInterrupt:)
         
                                                    name:AVPlayerItemPlaybackStalledNotification
         
                                                  object:self.playerItem];
        // 监听播放状态
        [self.playerItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
        // 监听loadedTimeRanges属性
        [self.playerItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionNew context:nil];
        
        [self.playerItem addObserver:self forKeyPath:@"playbackBufferEmpty" options:NSKeyValueObservingOptionNew context:nil];
        // Will warn you when your buffer is good to go again.
        [self.playerItem addObserver:self forKeyPath:@"playbackLikelyToKeepUp" options:NSKeyValueObservingOptionNew context:nil];
        [self setTheProgressOfPlayTime];
        [self.videoMaskView.activityView startAnimating];
    }
}
- (MPVolumeView *)volumeView {
    if (_volumeView == nil) {
        _volumeView  = [[MPVolumeView alloc] init];
        [_volumeView sizeToFit];
        for (UIView *view in [_volumeView subviews]){
            if ([view.class.description isEqualToString:@"MPVolumeSlider"]){
                self.volumeViewSlider = (UISlider*)view;
                self.volumeViewSlider.hidden = YES;
                break;
            }
        }
        
        [_volumeView  setShowsVolumeSlider:YES];
        [_volumeView  setShowsRouteButton:NO];
    }
    return _volumeView;
}
-(instancetype)initWithFrame:(CGRect)frame{
    if ([super initWithFrame:frame]) {
        [self addSubviews];
    }
    return self;
}
-(void)addSubviews{

    self.player = [[AVPlayer alloc]init];
    if([[UIDevice currentDevice] systemVersion].floatValue >= 10.0){
        //      增加下面这行可以解决iOS10兼容性问题了
        self.player.automaticallyWaitsToMinimizeStalling = NO;
    }
    
    self.playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
    self.playerLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    self.playerLayer.frame = self.frame;
    self.smallFrame = self.frame;
    self.bigFrame = CGRectMake(0, 0,[UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [self.layer insertSublayer:self.playerLayer atIndex:0];
     __weak typeof(self) weakself = self;
    
    self.videoMaskView = [[VideoMaskView alloc]initWithFrame:self.frame
                                                   playBtnClick:^(UIButton *playBtn) {
                                                       [weakself playBtnClick:playBtn];
                                                   } fullScreenBtnClick:^(UIButton *fullScreenBtn) {
                                                       
                                                       [weakself fullScreenClick:fullScreenBtn];
                                                   }];
    
    

    self.videoMaskView.touchDelegate = self;
    
    [self addSubview:self.videoMaskView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidEnterBackground) name:UIApplicationWillResignActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidEnterPlayGround) name:UIApplicationDidBecomeActiveNotification object:nil];
   
 
}

- (void)touchesBeganWithPoint:(CGPoint)point {
    //记录首次触摸坐标
    self.startPoint = point;
    //检测用户是触摸屏幕的左边还是右边，以此判断用户是要调节音量还是亮度，左边是亮度，右边是音量
    if (self.startPoint.x <= self.videoMaskView.frame.size.width / 2.0) {
        //亮度
        self.startVB = [UIScreen mainScreen].brightness;
    } else {
        //音/量
        self.startVB = self.volumeViewSlider.value;
    }
    //方向置为无
    self.direction = DirectionNone;
    //记录当前视频播放的进度
    CMTime ctime = self.player.currentTime;
    self.startVideoRate = ctime.value / ctime.timescale / self.total;
    
}

#pragma mark - 结束触摸
- (void)touchesEndWithPoint:(CGPoint)point {
    if (self.direction == DirectionLeftOrRight) {
        if (!self.playerItem || ![self.player currentItem].duration.value || ![self.player currentItem].duration.timescale) {
            return;
        }
        [self.player pause];
        // [self.videoMaskView.activityView startAnimating];
        CGFloat total = [self.player currentItem].duration.value / [self.player currentItem].duration.timescale;
        CGFloat current = total *  self.videoMaskView.videoSlider.value;
        CMTime dragTime = CMTimeMake(current, 1);
        
        __weak typeof(self) weakself = self;
        [self.player seekToTime:dragTime completionHandler:^(BOOL finished) {
            
            [weakself play];
            weakself.videoMaskView.bottomBackgroundView.hidden = NO;
        }];
        
    }
}

- (void)touchesMoveWithPoint:(CGPoint)point {
    //得出手指在Button上移动的距离
    CGPoint panPoint = CGPointMake(point.x - self.startPoint.x, point.y - self.startPoint.y);
    //分析出用户滑动的方向
    if (self.direction == DirectionNone) {
        if (panPoint.x >= 30 || panPoint.x <= -30) {
            //进度
            self.direction = DirectionLeftOrRight;
        } else if (panPoint.y >= 30 || panPoint.y <= -30) {
            //音量和亮度
            self.direction = DirectionUpOrDown;
        }
    }
    
    if (self.direction == DirectionNone) {
        return;
    } else if (self.direction == DirectionUpOrDown) {
        //音量和亮度
        if (self.startPoint.x <= self.videoMaskView.frame.size.width / 2.0) {
            //调节亮度
            if (panPoint.y < 0) {
                //增加亮度
                [[UIScreen mainScreen] setBrightness:self.startVB + (-panPoint.y / 30.0 / 10)];
            } else {
                //减少亮度
                [[UIScreen mainScreen] setBrightness:self.startVB - (panPoint.y / 30.0 / 10)];
            }
            
        } else {
            //音量
            if (panPoint.y < 0) {
                //增大音量
                
                [self.volumeViewSlider setValue:self.startVB + (-panPoint.y / 30.0 / 10) animated:YES];
                
            } else {
                //减少音量
                [self.volumeViewSlider setValue:self.startVB - (panPoint.y / 30.0 / 10) animated:YES];
            }
        }
    } else if (self.direction == DirectionLeftOrRight ) {
        //进度
        [self pause];
        CGFloat rate = self.videoMaskView.videoSlider.value + (panPoint.x / 300.0 / 20.0);
        NSLog(@"%lf",rate);
        
        
        if (rate > 1) {
            rate = 1;
        } else if (rate < 0) {
            rate = 0;
        }
        [self.videoMaskView.videoSlider setValue:rate animated:YES];
        
        if (!self.playerItem || ![self.player currentItem].duration.value || ![self.player currentItem].duration.timescale) {
            return;
        }
        
        CGFloat total = [self.player currentItem].duration.value / [self.player currentItem].duration.timescale;
        CGFloat current = total * self.videoMaskView.videoSlider.value;
        
        NSInteger proSec = (NSInteger)current % 60;
        
        NSInteger proMin = (NSInteger)current / 60;
        
        self.videoMaskView.currentTimeLabel.text = [NSString stringWithFormat:@"%02zd:%02zd", proMin, proSec];
        
        
   

        //self.currentRate = rate;
    }
}

// 应用退到后台
- (void)appDidEnterBackground
{
    [self pause];
}

// 应用进入前台
- (void)appDidEnterPlayGround
{
    if (!self.isUserPause) {
        [self play];
    }
}
-(void)fullScreenClick: (UIButton *)btn {
    btn.selected = !btn.selected;
    
    if (btn.selected) {
        
        [UIView animateWithDuration:0.3 animations:^{
            self.transform = CGAffineTransformMakeRotation(M_PI / 2);
        
        } completion:nil];
        self.currentDevDir = Right;
        self.frame = self.bigFrame;
        [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:NO];
        [[UIApplication sharedApplication] setStatusBarHidden: YES];
        
    }else {
        self.currentDevDir = Portrait;
        [UIView animateWithDuration:0.3 animations:^{
            self.transform = CGAffineTransformMakeRotation(M_PI * 2);
        } completion:nil];
        self.frame = self.smallFrame;
        [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:NO];
       
    }
    
    if (self.toFullScreenAction) {
        self.toFullScreenAction(btn);
    }
    
    
    
}

- (void)playBtnClick: (UIButton *)button {
    button.selected = !button.selected;
    
    if (button.selected) {
        
        self.isUserPause = NO;
        if (self.playerState != Playing) {
            [self.videoMaskView.activityView stopAnimating];
            [self play];
        }else {
            [self play];
        }
        
    }else {
        self.isUserPause = YES;
        [self pause];
    }
    
}
- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.videoMaskView.frame = self.bounds;
    self.playerLayer.frame = self.bounds;
}
-(void)play{
    
    [self.player play];
    self.videoMaskView.playBtn.selected = YES;
    self.playerState = Playing;
    
}
- (void)playInterrupt: (NSNotification *)notification {
    
    [self.videoMaskView.activityView startAnimating];
}
- (void)playDidEnd:(NSNotification *)notification
{
    
    [self.videoMaskView.activityView stopAnimating];
    
    __weak typeof(self) weakself = self;
    [self.player seekToTime:CMTimeMake(0, 1) completionHandler:^(BOOL finish){
        
        [weakself.videoMaskView.videoSlider setValue:0.0 animated:YES];
        weakself.videoMaskView.currentTimeLabel.text = @"00:00";
        
    }];
    
    self.playerState = Stoped;
    self.videoMaskView.playBtn.selected = NO;
    
    if (self.playEndBlock) {
        self.playEndBlock();
    }
}
#pragma mark - 滑杆滑动事件
/**开始拖动滑杆**/
-(void)progressSliderTouchBegan: (UISlider *)slider {
    
    if (!self.playerItem || ![self.player currentItem].duration.value || ![self.player currentItem].duration.timescale) {
        return;
    }
    
    self.isDragSlider = YES;
    
}

/**滑动中**/
- (void)progressSliderTouchValueChanged: (UISlider *)slider {
    
    if (!self.playerItem || ![self.player currentItem].duration.value || ![self.player currentItem].duration.timescale) {
        return;
    }
    
    CGFloat total = [self.player currentItem].duration.value / [self.player currentItem].duration.timescale;
    CGFloat current = total * slider.value;
    
    NSInteger proSec = (NSInteger)current % 60;
    
    NSInteger proMin = (NSInteger)current / 60;
    
    self.videoMaskView.currentTimeLabel.text = [NSString stringWithFormat:@"%02zd:%02zd", proMin, proSec];
}

/**滑动结束**/
- (void)progressSliderTouchEnd: (UISlider *)slider {
    if (!self.playerItem || ![self.player currentItem].duration.value || ![self.player currentItem].duration.timescale) {
        return;
    }
    [self.player pause];
   // [self.videoMaskView.activityView startAnimating];
    CGFloat total = [self.player currentItem].duration.value / [self.player currentItem].duration.timescale;
    CGFloat current = total * slider.value;
    CMTime dragTime = CMTimeMake(current, 1);
    
    __weak typeof(self) weakself = self;
    [self.player seekToTime:dragTime completionHandler:^(BOOL finished) {
        
        [weakself play];
        weakself.videoMaskView.bottomBackgroundView.hidden = NO;
    }];
    
}
//设置播放进度和时间
-(void)setTheProgressOfPlayTime
{
    __weak typeof(self) weakSelf = self;
    [self.player addPeriodicTimeObserverForInterval:CMTimeMake(1.0, 1.0) queue:dispatch_get_main_queue() usingBlock:^(CMTime time) {
        
        //如果是拖拽slider中就不执行.
        
        if (weakSelf.isDragSlider) {
            return ;
        }
        
        float current=CMTimeGetSeconds(time);
        float total=CMTimeGetSeconds([weakSelf.playerItem duration]);
        weakSelf.currentPlayTime = current;
        weakSelf.totalTime = total;
        
        if (current) {
            [weakSelf.videoMaskView.videoSlider setValue:(current/total) animated:YES];
        }
        
        //秒数
        NSInteger proSec = (NSInteger)current%60;
        //分钟
        NSInteger proMin = (NSInteger)current/60;
        
        //总秒数和分钟
        NSInteger durSec = (NSInteger)total%60;
        
        NSInteger durMin = (NSInteger)total/60;
        
        weakSelf.videoMaskView.currentTimeLabel.text = [NSString stringWithFormat:@"%02zd:%02zd", proMin, proSec];
        weakSelf.videoMaskView.totalTimeLabel.text = [NSString stringWithFormat:@"%02zd:%02zd", durMin, durSec];
        
    } ];
}
-(void)pause{

    [self.player pause];
    self.videoMaskView.playBtn.selected = NO;
    self.playerState = Pause;

}
-(void)dealloc {
    
    NSLog(@"VideoPlayer销毁了");
    
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    
    [self.playerItem removeObserver:self forKeyPath:@"playbackBufferEmpty"];
    [self.playerItem removeObserver:self forKeyPath:@"playbackLikelyToKeepUp"];
    [self.playerItem removeObserver:self forKeyPath:@"status"];
    [self.playerItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
}
- (void)addTargetOnSlider {
    
    [self.videoMaskView.videoSlider removeTarget:self action:@selector(progressSliderTouchBegan:) forControlEvents:UIControlEventTouchDown];
    [self.videoMaskView.videoSlider addTarget:self action:@selector(progressSliderTouchValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    [self.videoMaskView.videoSlider removeTarget:self action:@selector(progressSliderTouchEnd:) forControlEvents: UIControlEventTouchUpInside | UIControlEventTouchCancel | UIControlEventTouchUpOutside];
    
    [self.videoMaskView.videoSlider removeTarget:self action:@selector(progressSliderTouchBegan:) forControlEvents:UIControlEventTouchDown];
    
    [self.videoMaskView.videoSlider addTarget:self action:@selector(progressSliderTouchValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    [self.videoMaskView.videoSlider addTarget:self action:@selector(progressSliderTouchEnd:) forControlEvents: UIControlEventTouchUpInside | UIControlEventTouchCancel | UIControlEventTouchUpOutside];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    
    if (object == self.playerItem) {
        if ([keyPath isEqualToString:@"status"]) {
            
            if (self.player.status == AVPlayerStatusReadyToPlay) {
                [self.videoMaskView.activityView startAnimating];
                [self play];
                [self addTargetOnSlider];
                
            } else if (self.player.status == AVPlayerStatusFailed){
                [self.videoMaskView.activityView startAnimating];
                NSLog(@"不能播放");
            }
        } else if ([keyPath isEqualToString:@"loadedTimeRanges"]) {
            NSTimeInterval timeInterval = [self availableDuration];// 计算缓冲进度
            CMTime duration             = self.playerItem.duration;
            CGFloat totalDuration       = CMTimeGetSeconds(duration);
            [self.videoMaskView.progessView setProgress:timeInterval / totalDuration animated:NO];
            
        }else if ([keyPath isEqualToString:@"playbackLikelyToKeepUp"]) {
            [self.videoMaskView.activityView stopAnimating];
            
        }else if ([keyPath isEqualToString:@"playbackBufferEmpty"]) {
            
            [self.videoMaskView.activityView startAnimating];
        }
    }
}

- (NSTimeInterval)availableDuration {
    NSArray *loadedTimeRanges = [[_player currentItem] loadedTimeRanges];
    CMTimeRange timeRange = [loadedTimeRanges.firstObject CMTimeRangeValue];// 获取缓冲区域
    float startSeconds = CMTimeGetSeconds(timeRange.start);
    float durationSeconds = CMTimeGetSeconds(timeRange.duration);
    NSTimeInterval result = startSeconds + durationSeconds;// 计算缓冲总进度
    return result;
}

- (double)playProgessScale {
    
    double scale = (double)self.currentPlayTime / (double)self.totalTime;
    
    return scale;
}
@end
