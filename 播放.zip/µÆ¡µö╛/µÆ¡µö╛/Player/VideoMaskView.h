//
//  VideoMaskView.h
//  播放
//
//  Created by Apple on 2017/6/27.
//  Copyright © 2017年 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol VideoMaskViewDelegate <NSObject>

/**
 * 开始触摸
 */
- (void)touchesBeganWithPoint:(CGPoint)point;

/**
 * 结束触摸
 */
- (void)touchesEndWithPoint:(CGPoint)point;

/**
 * 移动手指
 */
- (void)touchesMoveWithPoint:(CGPoint)point;

@end

typedef void (^ButtonClick) (UIButton *button);

@interface VideoMaskView : UIView
@property (nonatomic, strong) UIActivityIndicatorView *activityView;

/**全屏切换按钮**/
@property (nonatomic, strong) UIButton *fullScreenBtn;

/**播放/暂停按钮**/
@property (nonatomic, strong) UIButton *playBtn;

/**当前播放时间label**/
@property (nonatomic, strong) UILabel *currentTimeLabel;

/**视频slider**/
@property (nonatomic, strong) UISlider *videoSlider;

/**总播放时间label**/
@property (nonatomic, strong) UILabel *totalTimeLabel;

/**缓冲进度条**/
@property (nonatomic, strong) UIProgressView *progessView;

/**底部backgroundView**/
@property (nonatomic, strong) UIView *bottomBackgroundView;


/**
 * 传递点击事件的代理
 */
@property (weak, nonatomic) id <VideoMaskViewDelegate> touchDelegate;


- (instancetype)initWithFrame:(CGRect)frame
                 playBtnClick: (void (^) (UIButton *playBtn))playBtnClick
           fullScreenBtnClick: (void (^) (UIButton *fullScreenBtn))fullScreenBtnClick;

@end
