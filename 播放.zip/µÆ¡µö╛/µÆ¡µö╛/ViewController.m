//
//  ViewController.m
//  播放
//
//  Created by Apple on 2017/6/27.
//  Copyright © 2017年 Apple. All rights reserved.
//

#import "ViewController.h"
#import "PlayView.h"

@interface ViewController ()
{

    MPVolumeView *volumeView;
}
@property(nonatomic,strong) PlayView *playView ;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.playView = [PlayView playViewWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 250) playWithUrl:@"http://baobab.wdjcdn.com/1455782903700jy.mp4"];
    [self.view addSubview:self.playView];
    
    volumeView = self.playView.volumeView;
    [self.view addSubview:volumeView];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    
    volumeView.center = self.view.center;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
